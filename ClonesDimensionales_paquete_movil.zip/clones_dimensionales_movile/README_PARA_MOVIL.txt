CLONES DIMENSIONALES — COMPILAR APK SOLO CON EL MOVIL

No necesitas instalar Android Studio. La compilación se hará gratis en GitHub Actions (requiere cuenta de GitHub y conexión a Internet solo durante la compilación; el juego final funciona offline).

PASOS:
1) En el navegador del móvil abre https://github.com/ y crea/inicia sesión en tu cuenta.
2) Pulsa + > New repository. Nombre: clones-dimensionales-apk. Selecciona Public o Private y crea el repositorio.
3) En el repositorio: Add file > Upload files. Sube el archivo clones_dimensionales_android_source.zip de este paquete y pulsa Commit changes.
4) Pulsa Add file > Create new file.
5) En el nombre del archivo escribe exactamente: .github/workflows/build-apk.yml
6) Pega el contenido del archivo WORKFLOW_GITHUB.txt (incluido en este paquete) y pulsa Commit changes.
7) Abre la pestaña Actions. En la izquierda selecciona “Construir APK Android”. Pulsa Run workflow > Run workflow.
8) Espera a que termine con un visto verde. Abre esa ejecución y baja hasta Artifacts.
9) Descarga el artefacto “ClonesDimensionales-debug-apk”. GitHub descargará un ZIP. Ábrelo y extrae app-debug.apk.
10) Abre app-debug.apk desde Descargas y permite “Instalar aplicaciones desconocidas” para el navegador/gestor de archivos si Android lo solicita.

NOTAS:
- GitHub compila el APK en sus servidores. Necesitas Internet para subir el proyecto y descargar el APK.
- Una vez instalado, el juego está diseñado para funcionar sin Internet.
- Es un APK de depuración (debug), suficiente para instalarlo en tu móvil y probarlo.
- Si Android muestra una advertencia de seguridad, instala solo el APK que tú mismo has generado desde tu repositorio.
