# Clones Dimensionales: Idle Worlds — Android prototype 0.1

This repository contains an offline-first idle RPG prototype and a minimal Android WebView wrapper project.

## Play immediately
Open `app/src/main/assets/index.html` in a mobile browser or desktop browser. The prototype stores its save locally using localStorage. It requires no network connection after the file is present on the device.

## Build an Android APK
1. Install Android Studio with an Android SDK (API 23 or newer).
2. Open this folder as an Android Studio project.
3. Let Android Studio sync Gradle and install the requested SDK/build tools.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

The APK output will be under `app/build/outputs/apk/debug/`.

## Prototype scope
- Spanish UI, anime-inspired dark fantasy interface.
- Offline progression (up to 8 hours simulated when reopening).
- Clone creation and assignment to four fictional dimensions.
- Independent clone progress and probabilistic death simulation.
- On clone death, learned skills are inherited by Adrián; no memories are transferred.
- Local save data.

This is an early playable prototype. Balance, art assets, richer events, skill trees, and production testing remain to be developed.
